from flask import Flask, send_from_directory, request

app = Flask(__name__)


@app.route('/')
def client():
    return send_from_directory('cclient/dist', 'index.html')

@app.route('/message')
def generate_random():
    args = request.args
    print(args['name'])
    return "Hello " + args['name']
    

@app.route('/<path:path>')
def base(path):
    return send_from_directory('cclient/dist/assets', path)



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9200)
