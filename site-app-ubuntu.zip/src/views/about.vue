<template>
    <p class="text-3lg font-bold">About CentryPlan Building Services.</p>
</template>